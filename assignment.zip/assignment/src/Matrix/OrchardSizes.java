package Matrix;
import java.util.ArrayList;
import java.util.List;

public class OrchardSizes {
    public static List<Integer> computeOrchardSizes(char[][] matrix) {
        List<Integer> orchardSizes = new ArrayList<>();
        int rows = matrix.length;
        if (rows == 0) {
            return orchardSizes; // Empty matrix
        }
        int cols = matrix[0].length;
        
        // Visited array to keep track of visited locations
        boolean[][] visited = new boolean[rows][cols];
        
        // Traverse the matrix and find orchards
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (matrix[i][j] == 'T' && !visited[i][j]) {
                    int orchardSize = findOrchardSize(matrix, visited, i, j);
                    orchardSizes.add(orchardSize);
                }
            }
        }
        
        return orchardSizes;
    }
    
    // Recursive function to find the size of an orchard
    private static int findOrchardSize(char[][] matrix, boolean[][] visited, int row, int col) {
        int rows = matrix.length;
        int cols = matrix[0].length;
        
        // Check if the current location is valid and has a tree
        if (row < 0 || row >= rows || col < 0 || col >= cols || matrix[row][col] == 'O' || visited[row][col]) {
            return 0;
        }
        
        // Mark the current location as visited
        visited[row][col] = true;
        
        // Calculate the size of the orchard by recursively checking its neighbors
        int size = 1;
        size += findOrchardSize(matrix, visited, row - 1, col); // Up
        size += findOrchardSize(matrix, visited, row + 1, col); // Down
        size += findOrchardSize(matrix, visited, row, col - 1); // Left
        size += findOrchardSize(matrix, visited, row, col + 1); // Right
        size += findOrchardSize(matrix, visited, row - 1, col - 1); // Diagonal: Up-Left
        size += findOrchardSize(matrix, visited, row - 1, col + 1); // Diagonal: Up-Right
        size += findOrchardSize(matrix, visited, row + 1, col - 1); // Diagonal: Down-Left
        size += findOrchardSize(matrix, visited, row + 1, col + 1); // Diagonal: Down-Right
        
        return size;
    }
    
    public static void main(String[] args) {
        char[][] matrix = {
            {'O', 'T', 'O', 'O'},
            {'O', 'T', 'O', 'T'},
            {'T', 'T', 'O', 'T'},
            {'O', 'T', 'O', 'T'}
        };
        
        List<Integer> orchardSizes = computeOrchardSizes(matrix);
        
        System.out.println("Orchard Sizes:");
        for (int size : orchardSizes) {
            System.out.println(size);
        }
    }
}
